﻿namespace Entrevistas.Application.DTOs
{
    public record RecalculoCosmicVm(int TotalCFP, decimal Kloc);
}
