﻿namespace Entrevistas.Application.DTOs
{
    public record EffortMultiplierDto(string Nome, string Nivel, decimal Valor);
}
