﻿using Entrevistas.Application.DTOs;
using Entrevistas.Application.DTOs.Entrevistas;
using Entrevistas.Application.Interfaces;
using Entrevistas.Application.Services.Interfaces;
using Entrevistas.Domain.Entities;
using Entrevistas.Infrastructure;
using Entrevistas.Infrastructure.Database;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Entrevistas.Application.Services
{
    public class EntrevistaService : IEntrevistaService
    {
        private readonly AppDbContext _db;

        public EntrevistaService(AppDbContext db)
        {
            _db = db;
        }

        // =========================================================================
        // CREATE (fluxo antigo) - usa EntrevistaInputDto
        // =========================================================================
        public async Task<EntrevistaOutputDto> CriarEntrevistaAsync(EntrevistaInputDto dto)
        {
            var ent = new Entrevista
            {
                Id = Guid.NewGuid(),
                NomeEntrevista = dto.NomeEntrevista,
                NomeEntrevistado = dto.NomeEntrevistado,
                NomeEntrevistador = dto.NomeEntrevistador,
                DataEntrevista = dto.DataEntrevista,
                TipoEntrada = dto.TipoEntrada,   // enum do seu projeto
                Linguagem = dto.Linguagem
            };

            // SF
            ent.ScaleFactors = (dto.ScaleFactors ?? new List<ScaleFactorDto>())
                .Select(s => new ScaleFactor
                {
                    Id = Guid.NewGuid(),
                    EntrevistaId = ent.Id,
                    Nome = s.Nome,
                    Nivel = s.Nivel,
                    Valor = s.Valor
                })
                .ToList();

            // EM
            ent.EffortMultipliers = (dto.EffortMultipliers ?? new List<EffortMultiplierDto>())
                .Select(m => new EffortMultiplier
                {
                    Id = Guid.NewGuid(),
                    EntrevistaId = ent.Id,
                    Nome = m.Nome,
                    Nivel = m.Nivel,
                    Valor = m.Valor
                })
                .ToList();

            // CFP por totais (não usamos dto.Funcionalidades porque você não tem essa propriedade nesse DTO)
            var e = dto.Entradas;
            var x = dto.Saidas;
            var r = dto.Leitura;
            var w = dto.Gravacao;
            ent.TotalCFP = e + x + r + w;

            // KLOC a partir de CFP (se > 0); senão 0 (mantém compatibilidade para PF sem KLOC informado)
            ent.TamanhoKloc = await CalcularKlocDeCosmicAsync(ent.TotalCFP, default);

            await RecalcularCocomoEarlyDesignAsync(ent, default);

            _db.Entrevistas.Add(ent);
            await _db.SaveChangesAsync();

            return new EntrevistaOutputDto
            {
                Id = ent.Id,
                NomeEntrevista = ent.NomeEntrevista,
                EsforcoPM = ent.EsforcoPM,
                PrazoMeses = ent.PrazoMeses,
                TamanhoKloc = ent.TamanhoKloc
            };
        }

        // =========================================================================
        // LIST / GET
        // =========================================================================
        public async Task<IEnumerable<EntrevistaOutputDto>> ListarEntrevistasAsync()
        {
            var list = await _db.Entrevistas.AsNoTracking().ToListAsync();

            return list.Select(e => new EntrevistaOutputDto
            {
                Id = e.Id,
                NomeEntrevista = e.NomeEntrevista,
                EsforcoPM = e.EsforcoPM,
                PrazoMeses = e.PrazoMeses,
                TamanhoKloc = e.TamanhoKloc
            });
        }

        public async Task<EntrevistaOutputDto?> ObterPorIdAsync(Guid id)
        {
            var e = await _db.Entrevistas
                .AsNoTracking()
                .Include(x => x.ScaleFactors)
                .Include(x => x.EffortMultipliers)
                .Include(x => x.Funcionalidades).ThenInclude(f => f.Medicao)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (e == null) return null;

            return new EntrevistaOutputDto
            {
                Id = e.Id,
                NomeEntrevista = e.NomeEntrevista,
                EsforcoPM = e.EsforcoPM,
                PrazoMeses = e.PrazoMeses,
                TamanhoKloc = e.TamanhoKloc
            };
        }

        // =========================================================================
        // FUNCIONALIDADES
        // =========================================================================
        public async Task<Guid> AdicionarFuncionalidadeAsync(Guid entrevistaId, NovaFuncDto dto)
        {
            var ent = await _db.Entrevistas
                .Include(x => x.Funcionalidades).ThenInclude(f => f.Medicao)
                .Include(x => x.ScaleFactors)
                .Include(x => x.EffortMultipliers)
                .FirstOrDefaultAsync(x => x.Id == entrevistaId);

            if (ent == null)
                throw new KeyNotFoundException("Entrevista não encontrada.");

            var e = dto.Entradas;
            var x = dto.Saidas;
            var r = dto.Leitura;
            var w = dto.Gravacao;

            var fid = Guid.NewGuid();
            var func = new Funcionalidade
            {
                Id = fid,
                EntrevistaId = ent.Id,
                Nome = dto.Nome,
                Template = dto.Template,
                Observacoes = dto.Observacoes,
                Medicao = new MedicaoCosmic
                {
                    Id = Guid.NewGuid(),
                    FuncionalidadeId = fid,
                    EntryE = e,
                    ExitX = x,
                    ReadR = r,
                    WriteW = w
                }
            };

            _db.Funcionalidades.Add(func);
            await _db.SaveChangesAsync();

            // Reconta CFP a partir das funcionalidades e recalcula
            await RecontarCfpERecalcularAsync(entrevistaId);
            return fid;
        }

        public async Task<IReadOnlyList<FuncionalidadeVm>> ListarFuncionalidadesAsync(Guid entrevistaId)
        {
            var funcs = await _db.Funcionalidades
                .AsNoTracking()
                .Include(f => f.Medicao)
                .Where(f => f.EntrevistaId == entrevistaId)
                .ToListAsync();

            var list = new List<FuncionalidadeVm>(funcs.Count);
            foreach (var f in funcs)
            {
                var e = f.Medicao?.EntryE ?? 0;
                var x = f.Medicao?.ExitX ?? 0;
                var r = f.Medicao?.ReadR ?? 0;
                var w = f.Medicao?.WriteW ?? 0;
                var total = e + x + r + w;

                // CONSTRUTOR POSICIONAL exigido pelo seu projeto
                list.Add(new FuncionalidadeVm(
                    f.Id,
                    f.Nome,
                    f.Template,
                    f.Observacoes,
                    e, x, r, w, total
                ));
            }
            return list;
        }

        // =========================================================================
        // RECALC
        // =========================================================================
        public async Task<RecalculoCosmicVm> RecalcularCosmicAsync(Guid entrevistaId)
        {
            var ent = await _db.Entrevistas
                .Include(e => e.ScaleFactors)
                .Include(e => e.EffortMultipliers)
                .Include(e => e.Funcionalidades).ThenInclude(f => f.Medicao)
                .FirstOrDefaultAsync(x => x.Id == entrevistaId);

            if (ent == null)
                throw new KeyNotFoundException("Entrevista não encontrada.");

            // Reconta CFP via funcionalidades
            ent.TotalCFP = ent.Funcionalidades.Sum(f =>
                (f.Medicao?.EntryE ?? 0) +
                (f.Medicao?.ExitX ?? 0) +
                (f.Medicao?.ReadR ?? 0) +
                (f.Medicao?.WriteW ?? 0));

            // Se tiver CFP, converte para KLOC; senão mantém KLOC atual
            if (ent.TotalCFP > 0)
                ent.TamanhoKloc = await CalcularKlocDeCosmicAsync(ent.TotalCFP, default);

            await RecalcularCocomoEarlyDesignAsync(ent, default);
            await _db.SaveChangesAsync();

            // CONSTRUTOR POSICIONAL: (int totalCFP, decimal tamanhoKloc)
            return new RecalculoCosmicVm(ent.TotalCFP, ent.TamanhoKloc);
        }

        // =========================================================================
        // CREATE (rota que usa CreateEntrevistaDto)
        // =========================================================================
        public async Task<CreateEntrevistaResult> CriarEntrevistaComCosmicAsync(CreateEntrevistaDto dto)
        {
            var ent = new Entrevista
            {
                Id = Guid.NewGuid(),
                NomeEntrevista = dto.NomeEntrevista,
                NomeEntrevistado = dto.NomeEntrevistado,
                NomeEntrevistador = dto.NomeEntrevistador,
                DataEntrevista = dto.DataEntrevista,
                TipoEntrada = dto.TipoEntrada, // enum do seu projeto
                Linguagem = dto.Linguagem
            };

            // Fatores
            ent.ScaleFactors = (dto.ScaleFactors ?? new List<ScaleFactorDto>())
                .Select(s => new ScaleFactor
                {
                    Id = Guid.NewGuid(),
                    EntrevistaId = ent.Id,
                    Nome = s.Nome,
                    Nivel = s.Nivel,
                    Valor = s.Valor
                })
                .ToList();

            ent.EffortMultipliers = (dto.EffortMultipliers ?? new List<EffortMultiplierDto>())
                .Select(m => new EffortMultiplier
                {
                    Id = Guid.NewGuid(),
                    EntrevistaId = ent.Id,
                    Nome = m.Nome,
                    Nivel = m.Nivel,
                    Valor = m.Valor
                })
                .ToList();

            // CFP por totais do DTO (seu CreateEntrevistaDto não tem Funcionalidades)
            var e = dto.Entradas;
            var x = dto.Saidas;
            var r = dto.Leitura;
            var w = dto.Gravacao;
            ent.TotalCFP = e + x + r + w;

            // KLOC via conversão COSMIC (se CFP>0); caso contrário 0
            ent.TamanhoKloc = await CalcularKlocDeCosmicAsync(ent.TotalCFP, default);

            await RecalcularCocomoEarlyDesignAsync(ent, default);

            _db.Entrevistas.Add(ent);
            await _db.SaveChangesAsync();

            // CONSTRUTOR POSICIONAL: (Guid id, int totalCFP, decimal? tamanhoKloc)
            return new CreateEntrevistaResult(ent.Id, ent.TotalCFP, ent.TamanhoKloc);
        }

        // =========================================================================
        // UPDATE / DELETE
        // =========================================================================
        public async Task<bool> UpdateAsync(UpdateEntrevistaRequest request, CancellationToken ct = default)
        {
            var ent = await _db.Entrevistas
                .Include(e => e.ScaleFactors)
                .Include(e => e.EffortMultipliers)
                .Include(e => e.Funcionalidades).ThenInclude(f => f.Medicao)
                .FirstOrDefaultAsync(e => e.Id == request.Id, ct);

            if (ent == null) return false;

            // Básicos
            ent.NomeEntrevista = request.NomeEntrevista;
            ent.NomeEntrevistado = request.NomeEntrevistado;
            ent.NomeEntrevistador = request.NomeEntrevistador;
            ent.DataEntrevista = request.DataEntrevista;
            ent.TipoEntrada = request.TipoEntrada;
            ent.Linguagem = request.Linguagem;

            // Substitui SF/EM
            _db.ScaleFactors.RemoveRange(ent.ScaleFactors);
            _db.EffortMultipliers.RemoveRange(ent.EffortMultipliers);

            ent.ScaleFactors = (request.ScaleFactors ?? new List<ScaleFactorDto>())
                .Select(s => new ScaleFactor
                {
                    Id = Guid.NewGuid(),
                    EntrevistaId = ent.Id,
                    Nome = s.Nome,
                    Nivel = s.Nivel,
                    Valor = s.Valor
                })
                .ToList();

            ent.EffortMultipliers = (request.EffortMultipliers ?? new List<EffortMultiplierDto>())
                .Select(m => new EffortMultiplier
                {
                    Id = Guid.NewGuid(),
                    EntrevistaId = ent.Id,
                    Nome = m.Nome,
                    Nivel = m.Nivel,
                    Valor = m.Valor
                })
                .ToList();

            // **Não** esperamos funcionalidades no UpdateRequest (para evitar conflitos).
            // Portanto, o TotalCFP será recalculado:
            // - Se já existirem funcionalidades cadastradas -> soma via funcionalidades
            // - Caso contrário -> usa os totais do request (Entradas/Saidas/Leitura/Gravacao)
            if (ent.Funcionalidades.Any())
            {
                ent.TotalCFP = ent.Funcionalidades.Sum(f =>
                    (f.Medicao?.EntryE ?? 0) +
                    (f.Medicao?.ExitX ?? 0) +
                    (f.Medicao?.ReadR ?? 0) +
                    (f.Medicao?.WriteW ?? 0));
            }
            else
            {
                var eTot = request.Entradas;
                var xTot = request.Saidas;
                var rTot = request.Leitura;
                var wTot = request.Gravacao;
                ent.TotalCFP = eTot + xTot + rTot + wTot;
            }

            // KLOC: se CFP>0, converte; senão mantém (PF sem KLOC)
            if (ent.TotalCFP > 0)
                ent.TamanhoKloc = await CalcularKlocDeCosmicAsync(ent.TotalCFP, ct);

            await RecalcularCocomoEarlyDesignAsync(ent, ct);
            await _db.SaveChangesAsync(ct);
            return true;
        }

        public async Task<bool> DeleteAsync(DeleteEntrevistaRequest request, CancellationToken ct = default)
        {
            var ent = await _db.Entrevistas.FirstOrDefaultAsync(e => e.Id == request.Id, ct);
            if (ent == null) return false;

            _db.Entrevistas.Remove(ent); // ON DELETE CASCADE nas FKs cuida dos filhos
            await _db.SaveChangesAsync(ct);
            return true;
        }

        // =========================================================================
        // Helpers
        // =========================================================================
        private async Task RecontarCfpERecalcularAsync(Guid entrevistaId)
        {
            var ent = await _db.Entrevistas
                .Include(e => e.ScaleFactors)
                .Include(e => e.EffortMultipliers)
                .Include(e => e.Funcionalidades).ThenInclude(f => f.Medicao)
                .FirstAsync(e => e.Id == entrevistaId);

            ent.TotalCFP = ent.Funcionalidades.Sum(f =>
                (f.Medicao?.EntryE ?? 0) +
                (f.Medicao?.ExitX ?? 0) +
                (f.Medicao?.ReadR ?? 0) +
                (f.Medicao?.WriteW ?? 0));

            if (ent.TotalCFP > 0)
                ent.TamanhoKloc = await CalcularKlocDeCosmicAsync(ent.TotalCFP, default);

            await RecalcularCocomoEarlyDesignAsync(ent, default);
            await _db.SaveChangesAsync();
        }

        private async Task<decimal> CalcularKlocDeCosmicAsync(int totalCfp, CancellationToken ct)
        {
            if (totalCfp <= 0) return 0m;

            // Conversão COSMIC -> KLOC (Contexto "Geral")
            var conv = await _db.ConversoesTamanho.AsNoTracking()
                .FirstOrDefaultAsync(x => x.TipoEntrada == "COSMIC" && x.Contexto == "Geral", ct);

            var fator = conv != null ? conv.FatorConversao : 0.025m;
            var kloc = (decimal)totalCfp * fator;
            return Math.Round(kloc, 6, MidpointRounding.AwayFromZero);
        }

        private async Task RecalcularCocomoEarlyDesignAsync(Entrevista ent, CancellationToken ct)
        {
            // ΣSF
            ent.SomaScaleFactors = ent.ScaleFactors.Sum(s => s.Valor);

            // ΠEM
            decimal produtoEm = 1m;
            foreach (var em in ent.EffortMultipliers)
                produtoEm *= em.Valor;
            ent.ProdutoEffortMultipliers = produtoEm;

            // Parâmetros (tabela ParametrosCocomo)
            var p = await _db.ParametrosCocomo.AsNoTracking().FirstOrDefaultAsync(ct);
            if (p == null)
            {
                p = new ParametrosCocomo { A = 2.94m, B = 0.91m, C = 3.67m, D = 0.28m };
            }

            // PM = A * Size^(B + 0.01*ΣSF) * ΠEM
            var expoente = p.B + 0.01m * ent.SomaScaleFactors;
            var sizePow = (decimal)Math.Pow((double)ent.TamanhoKloc, (double)expoente);
            ent.EsforcoPM = Math.Round(p.A * sizePow * ent.ProdutoEffortMultipliers, 6, MidpointRounding.AwayFromZero);

            // Prazo = C * PM^D
            var pmPow = (decimal)Math.Pow((double)ent.EsforcoPM, (double)p.D);
            ent.PrazoMeses = Math.Round(p.C * pmPow, 6, MidpointRounding.AwayFromZero);
        }
    }
}
