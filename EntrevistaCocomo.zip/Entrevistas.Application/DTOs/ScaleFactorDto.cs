﻿namespace Entrevistas.Application.DTOs
{
    public record ScaleFactorDto(string Nome, string Nivel, decimal Valor);
}
