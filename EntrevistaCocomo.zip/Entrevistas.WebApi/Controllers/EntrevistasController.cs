﻿using Entrevistas.Application.DTOs;
using Entrevistas.Application.DTOs.Entrevistas;
using Entrevistas.Application.DTOs.Entrevistas.Partial;
using Entrevistas.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace Entrevistas.WebApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class EntrevistasController : ControllerBase
    {
        private readonly IEntrevistaService _service;

        public EntrevistasController(IEntrevistaService service)
        {
            _service = service;
        }

        [HttpPost]
        public async Task<ActionResult<EntrevistaOutputDto>> Post([FromBody] EntrevistaInputDto dto)
        {
            var resultado = await _service.CriarEntrevistaAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = resultado.Id }, resultado);
        }

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var entrevistas = await _service.ListarEntrevistasAsync();
            return Ok(entrevistas);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(Guid id)
        {
            var entrevista = await _service.ObterPorIdAsync(id);
            if (entrevista == null) return NotFound();
            return Ok(entrevista);
        }

        [HttpPost("com-cosmic")]
        public async Task<ActionResult<CreateEntrevistaResult>> PostComCosmic([FromBody] CreateEntrevistaDto dto)
        {
            var result = await _service.CriarEntrevistaComCosmicAsync(dto);
            return CreatedAtAction(nameof(GetById), new { id = result.Id }, result);
        }

        /// <summary>
        /// Exclui uma entrevista e todos os dados dependentes (cascade).
        /// </summary>
        [HttpDelete("{id:guid}")]
        public async Task<IActionResult> Delete(Guid id, CancellationToken ct)
        {
            var ok = await _service.DeleteAsync(new DeleteEntrevistaRequest(id), ct);
            return ok ? NoContent() : NotFound();
        }

        /// <summary>Edita dados básicos da entrevista.</summary>
        [HttpPut("{id:guid}")]
        public async Task<IActionResult> Put(Guid id, [FromBody] UpdateEntrevistaRequest body, CancellationToken ct)
        {
            if (id != body.Id) return BadRequest("Id do path difere do body.");
            var ok = await _service.UpdateAsync(body, ct);
            return ok ? NoContent() : NotFound();
        }
    }
}