﻿namespace Entrevistas.Application.DTOs
{
    public record MedicaoDto(int E, int X, int R, int W);
}
