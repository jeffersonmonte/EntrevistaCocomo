﻿namespace Entrevistas.Application.DTOs.Entrevistas;

public sealed record DeleteEntrevistaRequest(Guid Id);
