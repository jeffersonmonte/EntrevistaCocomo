﻿namespace Entrevistas.Domain.Enums
{
    public enum TipoEntradaTamanho
    {
        KLOC = 1,
        PontosDeFuncao = 2,
        Cosmic = 3
    }
}
