﻿namespace Entrevistas.Application.DTOs
{
    public class ResultadoCocomoDto
    {
        public decimal KlocConvertido { get; set; }
        public decimal EsforcoPM { get; set; }
        public decimal PrazoMeses { get; set; }
    }
}
