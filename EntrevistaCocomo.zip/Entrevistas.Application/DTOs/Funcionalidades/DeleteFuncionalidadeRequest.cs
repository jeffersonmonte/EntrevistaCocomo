﻿namespace Entrevistas.Application.DTOs.Funcionalidades;

public sealed record DeleteFuncionalidadeRequest(Guid Id);
