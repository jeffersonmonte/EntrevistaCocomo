﻿namespace Entrevistas.Domain.Entities
{
    public class ParametrosCocomo
    {
        public int Id { get; set; }
        public decimal A { get; set; }
        public decimal B { get; set; }
        public decimal C { get; set; }
        public decimal D { get; set; }
    }
}
