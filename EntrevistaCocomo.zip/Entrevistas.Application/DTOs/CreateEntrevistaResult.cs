namespace Entrevistas.Application.DTOs
{
    public record CreateEntrevistaResult(Guid Id, int TotalCFP, decimal? TamanhoKloc);
}
